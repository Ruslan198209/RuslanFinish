package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String pervoeSlovo = "Привет,";
        String vtoroeSlovo = "мир!";
        System.out.println(pervoeSlovo+vtoroeSlovo);
        System.out.println("Как вас зовут?");
    boolean isRuslan = true;
        if (isRuslan) {
            System.out.println("Привет, Руслан!");
        }


    }
}
